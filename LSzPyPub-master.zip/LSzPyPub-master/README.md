# hello ITdigital

In this GitHub repository you will find everything used to create our binder repository.

https://mybinder.org/v2/gh/LSzCode/LSzPyPub/master

Please create own public GitHub repositories to submit solutions for our advanced tasks. 

You can use your repositories to create own binder repositories aswell (<a href="https://www.youtube.com/watch?v=OK6M4w7LYIc">general overview</a>).
